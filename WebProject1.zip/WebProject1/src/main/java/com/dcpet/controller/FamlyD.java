package com.dcpet.controller;

public class FamlyD {

	
	String fatherFirst;
	String fatherLast;
	String motherFirst;
	String motherLast;
	String siblings;
	String familySize;
	
	
	public String getFatherFirst() {
		return fatherFirst;
	}
	public void setFatherFirst(String fatherFirst) {
		this.fatherFirst = fatherFirst;
	}
	public String getFatherLast() {
		return fatherLast;
	}
	public void setFatherLast(String fatherLast) {
		this.fatherLast = fatherLast;
	}
	public String getMotherFirst() {
		return motherFirst;
	}
	public void setMotherFirst(String motherFirst) {
		this.motherFirst = motherFirst;
	}
	public String getMotherLast() {
		return motherLast;
	}
	public void setMotherLast(String motherLast) {
		this.motherLast = motherLast;
	}
	public String getSiblings() {
		return siblings;
	}
	public void setSiblings(String siblings) {
		this.siblings = siblings;
	}
	public String getFamilySize() {
		return familySize;
	}
	public void setFamilySize(String familySize) {
		this.familySize = familySize;
	}
	
}
